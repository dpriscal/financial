matches <- function(x){
  list(nrow=nrow(x), matches=attr(x, 'matches'))
}
hits <- function(x){
  list(nrow=nrow(x), matches=attr(x, 'matches'))
}

